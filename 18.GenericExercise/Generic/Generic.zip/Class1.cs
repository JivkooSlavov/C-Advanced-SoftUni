﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic
{
    class Class1 : IComparable
    {
        public int CompareTo(object obj)
        {
           throw new NotImplementedException();
        }
    }
}
